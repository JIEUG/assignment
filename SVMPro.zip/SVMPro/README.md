
- data 目录 存放数据
- main.py 主要程序
- requirements.txt 程序依赖文件

### 首先安装依赖包
`pip insatll -r requiremnets.txt`

### 运行程序
`python main.py`