import pandas as pd
import numpy as np
import arff
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.impute import SimpleImputer, KNNImputer
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.feature_selection import RFE
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, \
    ConfusionMatrixDisplay


def load_data(file_path):
    """加载ARFF文件并返回DataFrame"""
    with open(file_path, 'r') as f:
        arff_data = arff.load(f)
    data = arff_data['data']
    attributes = arff_data['attributes']
    column_names = [attr[0] for attr in attributes]
    df = pd.DataFrame(data, columns=column_names)
    return df


def preprocess_data(df):
    """数据清理与预处理"""
    # 替换 '?' 为 NaN
    df.replace('?', np.nan, inplace=True)

    # 将相关列转换为数值类型
    numeric_columns = ['age', 'bp', 'sg', 'al', 'su', 'bgr', 'bu', 'sc',
                       'sod', 'pot', 'hemo', 'pcv', 'wbcc', 'rbcc']
    for col in numeric_columns:
        df[col] = pd.to_numeric(df[col], errors='coerce')

    # 将分类变量映射为数值
    binary_mapping = {'yes': 1, 'no': 0, 'present': 1, 'notpresent': 0, 'abnormal': 1, 'normal': 0,
                      'good': 1, 'poor': 0, 'ckd': 1, 'notckd': 0}
    df.replace(binary_mapping, inplace=True)

    return df, numeric_columns


def basic_statistics(df):
    """输出数据的基本统计信息和可视化"""
    print(df.describe())
    sns.histplot(df['age'].dropna(), kde=True)
    plt.title('Age Distribution')
    plt.show()


def handle_missing_values(df, numeric_columns):
    """使用KNN Imputer处理缺失值"""
    knn_imputer = KNNImputer(n_neighbors=5)
    df[numeric_columns] = knn_imputer.fit_transform(df[numeric_columns])
    return df


def feature_selection(X, y, numeric_features, n_features_to_select=10):
    """特征选择"""
    model = LogisticRegression(max_iter=10000)
    rfe = RFE(model, n_features_to_select=n_features_to_select)
    rfe.fit(X, y)
    selected_features = [numeric_features[i] for i in range(len(numeric_features)) if rfe.support_[i]]
    print("Selected Features:", selected_features)
    return selected_features


def build_pipeline(numeric_features, categorical_features):
    """构建预处理和特征选择的Pipeline"""
    numeric_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='mean')),
        ('scaler', StandardScaler())])

    categorical_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='most_frequent')),
        ('onehot', OneHotEncoder(handle_unknown='ignore'))])

    preprocessor = ColumnTransformer(
        transformers=[
            ('num', numeric_transformer, numeric_features),
            ('cat', categorical_transformer, categorical_features)])

    return preprocessor


def train_logistic_regression(X_train, y_train):
    """训练逻辑回归模型"""
    model = LogisticRegression(max_iter=10000, random_state=42)
    model.fit(X_train, y_train)
    return model


def train_decision_tree(X_train, y_train):
    """训练决策树模型"""
    param_grid = {
        'max_depth': [3, 5, 7, None],
        'min_samples_split': [2, 5, 10],
        'min_samples_leaf': [1, 2, 4],
        'criterion': ['gini', 'entropy']
    }

    grid_search = GridSearchCV(DecisionTreeClassifier(random_state=42), param_grid, cv=5, scoring='accuracy')
    grid_search.fit(X_train, y_train)
    print(f"Best parameters for Decision Tree: {grid_search.best_params_}")

    best_tree_model = grid_search.best_estimator_
    best_tree_model.fit(X_train, y_train)
    return best_tree_model


def evaluate_model(model, X_test, y_test, model_name="Model"):
    """评估模型性能"""
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)
    recall = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)

    print(f"{model_name} Accuracy: {accuracy:.2f}")
    print(f"{model_name} Precision: {precision:.2f}")
    print(f"{model_name} Recall: {recall:.2f}")
    print(f"{model_name} F1 Score: {f1:.2f}")

    # 混淆矩阵可视化
    cm = confusion_matrix(y_test, y_pred)
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=['notckd', 'ckd'])
    disp.plot()
    plt.title(f"{model_name} Confusion Matrix")
    plt.show()

    # 错误分析
    misclassified_samples = X_test[y_test != y_pred]
    print(f"Misclassified samples for {model_name}: {misclassified_samples}")


def main():
    # 1. 数据加载
    df = load_data('data/chronic_kidney_disease_full.arff')

    # 2. 数据清理与预处理
    df, numeric_columns = preprocess_data(df)
    basic_statistics(df)
    df = handle_missing_values(df, numeric_columns)

    # 3. 分离特征和目标变量
    X = df.drop('class', axis=1)
    y = df['class'].astype(int)

    # 4. 构建Pipeline
    numeric_features = X.select_dtypes(include=[np.number]).columns.tolist()
    categorical_features = X.select_dtypes(exclude=[np.number]).columns.tolist()
    preprocessor = build_pipeline(numeric_features, categorical_features)

    # 5. 数据预处理
    X_preprocessed = preprocessor.fit_transform(X)

    # 6. 特征选择
    selected_features = feature_selection(X_preprocessed, y, numeric_features)
    X_selected = X_preprocessed[:, :len(selected_features)]  # 只保留被选中的特征

    # 7. 数据集划分
    X_train, X_test, y_train, y_test = train_test_split(X_selected, y, test_size=0.2, random_state=42)

    # 8. 模型训练和优化
    # 逻辑回归模型
    logistic_regression_model = train_logistic_regression(X_train, y_train)
    evaluate_model(logistic_regression_model, X_test, y_test, model_name="Logistic Regression")

    # 决策树模型
    decision_tree_model = train_decision_tree(X_train, y_train)
    evaluate_model(decision_tree_model, X_test, y_test, model_name="Decision Tree")

    # SVM模型
    svm_model = train_svm(X_train, y_train)
    evaluate_model(svm_model, X_test, y_test, model_name="SVM")


def train_svm(X_train, y_train):
    """使用SVM训练模型并进行参数优化"""
    param_grid = {
        'C': [0.1, 1, 10],
        'kernel': ['linear', 'rbf']
    }

    grid_search = GridSearchCV(SVC(random_state=42), param_grid, cv=5, scoring='accuracy')
    grid_search.fit(X_train, y_train)
    print(f"Best parameters for SVM: {grid_search.best_params_}")

    best_svm_model = grid_search.best_estimator_
    best_svm_model.fit(X_train, y_train)
    return best_svm_model


if __name__ == "__main__":
    main()
